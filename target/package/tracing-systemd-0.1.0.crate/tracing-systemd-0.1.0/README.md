# tracing-systemd: Journald logging with (some) formatting
Putting something here so the repo doesn't look quite so bare

### Run examples:
`cargo run --example test_log_stdout --features="colored"`

`cargo run --example test_log_systemd --features="colored"`